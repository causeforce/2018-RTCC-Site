1. Pull this repository to your WP installation > wp-content > themes > create a folder and rename it jupiter

2. In terminal cd to jupiter/js

3. Install nvm if it's not already then:

nvm use v6.10.0 || nvm install v6.10.0 || exit 1;

gulp --version || npm install -g gulp || exit 1;

yarn --version || npm install -g yarn || exit 1;

yarn

gulp build 