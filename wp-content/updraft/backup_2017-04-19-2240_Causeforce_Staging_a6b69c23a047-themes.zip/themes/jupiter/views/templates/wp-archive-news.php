<?php
if(shortcode_exists('mk_news')) {
		echo do_shortcode('[mk_news image_height="260" pagination_style="2"]');
}