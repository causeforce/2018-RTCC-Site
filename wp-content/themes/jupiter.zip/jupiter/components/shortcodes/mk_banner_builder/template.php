<div class="mk-flexslider mk-banner-builder mk-slideshow js-el js-flexslider" data-mk-component="BannerBuilder">
	<ul class="mk-banner-slides">
		<li class="mk-banner-slide"></li>
	</ul>
</div>