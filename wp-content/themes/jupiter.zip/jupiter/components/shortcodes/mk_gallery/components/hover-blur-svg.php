<?php if($view_params['hover_scenarios'] == 'blur') { ?>
<svg version="1.1" xmlns="http://www.w3.org/2000/svg">
	<filter id="gallery-blur">
		<feGaussianBlur stdDeviation="5" />
	</filter>
</svg>
<?php }